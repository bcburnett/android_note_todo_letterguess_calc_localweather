package com.newlondonweb.tabbedfragmentdemo.data.weather

data class DataXX(
    val precipIntensity: Double,
    val precipProbability: Double,
    val time: Int
)