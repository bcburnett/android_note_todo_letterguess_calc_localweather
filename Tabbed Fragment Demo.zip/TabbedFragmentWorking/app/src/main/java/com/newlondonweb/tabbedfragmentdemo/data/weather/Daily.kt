package com.newlondonweb.tabbedfragmentdemo.data.weather

data class Daily(
    val `data`: List<DataXX>,
    val icon: String,
    val summary: String
)