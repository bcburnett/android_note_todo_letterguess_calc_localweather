package com.newlondonweb.tabbedfragmentdemo.data.weather

data class DataXXX(
    val `data`: List<DataXXXX>
)