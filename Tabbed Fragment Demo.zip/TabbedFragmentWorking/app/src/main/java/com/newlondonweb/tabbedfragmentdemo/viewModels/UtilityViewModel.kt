package com.newlondonweb.tabbedfragmentdemo.viewModels

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class UtilityViewModel(application: Application) : AndroidViewModel(application)  {


}